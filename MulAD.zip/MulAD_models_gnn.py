import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import GCNConv, global_mean_pool, global_max_pool
from torch_geometric.data import Data, DataLoader
import numpy as np

def seq2graph(seq_feat, seq_idx):
    edge_index = []
    for i in range(len(seq_idx)-1):
        edge_index.append([i, i+1])
    edge_index += [[i, i] for i in range(len(seq_idx))]
    edge_index = torch.tensor(edge_index, dtype=torch.long).t().contiguous()
    x = torch.tensor(seq_feat, dtype=torch.float)
    data = Data(x=x, edge_index=edge_index)
    return data

class SimpleGNN(nn.Module):
    def __init__(self, node_dim, hidden=128, dropout=0.1):
        super().__init__()
        self.conv1 = GCNConv(node_dim, hidden)
        self.conv2 = GCNConv(hidden, hidden)
        self.fc = nn.Sequential(
            nn.Linear(hidden*2, 64),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(64, 2)
        )
    
    def forward(self, data):
        x, edge_index = data.x, data.edge_index
        x = F.relu(self.conv1(x, edge_index))
        x = F.dropout(x, p=0.1, training=self.training)
        x = self.conv2(x, edge_index)
        x_mean = global_mean_pool(x, data.batch) if hasattr(data, 'batch') else x.mean(dim=0, keepdim=True)
        x_max  = global_max_pool(x, data.batch) if hasattr(data, 'batch') else x.max(dim=0, keepdim=True)[0]
        x = torch.cat([x_mean, x_max], dim=1)
        return self.fc(x)

def build_graph_dataset(X_vec, seq_idx_list):
    data_list = []
    for vec, idx in zip(X_vec, seq_idx_list):
        num_nodes = len(idx)
        node_feat = np.tile(vec, (num_nodes, 1))
        data = seq2graph(node_feat, idx)
        data_list.append(data)
    return data_list

if __name__ == "__main__":
    dummy_feat = np.random.randn(10, 64)
    dummy_idx  = list(range(10))
    data = seq2graph(dummy_feat, dummy_idx)
    model = SimpleGNN(node_dim=64)
    out = model(data)
    print("GNN:", out.shape)