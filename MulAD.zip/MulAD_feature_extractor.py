import numpy as np
import pandas as pd
from collections import Counter, defaultdict
from utils import ts2sec, z_score_normalize
from transformers import AutoTokenizer, AutoModel
from sklearn.decomposition import PCA
import torch

tokenizer = AutoTokenizer.from_pretrained("bert-base-uncased")
bert_model = AutoModel.from_pretrained("bert-base-uncased")

def get_template_embedding(tmpl, embed_dim=64):
    inputs = tokenizer(tmpl, return_tensors="pt")
    with torch.no_grad():
        outputs = bert_model(**inputs)
    emb = outputs.last_hidden_state.mean(1).numpy().squeeze()
    if emb.shape[0] > embed_dim:
        pca = PCA(n_components=embed_dim)
        emb = pca.fit_transform(emb.reshape(1, -1)).squeeze()
    return emb

def extract_all_templates(sequences):
    return list(set(log["LT"] for seq in sequences for log in seq))

def extract_sequential(seq):
    lt2idx = {lt: idx for idx, lt in enumerate(TEMPLATE2VEC.keys())}
    return [lt2idx[log["LT"]] for log in seq if log["LT"] in lt2idx]

def extract_semantic(seq):
    vecs = [TEMPLATE2VEC[log["LT"]] for log in seq if log["LT"] in TEMPLATE2VEC]
    return np.mean(vecs, axis=0) if vecs else np.zeros(list(TEMPLATE2VEC.values())[0].shape[0])

def extract_quantitative(seq):
    counter = Counter([log["LT"] for log in seq])
    lt_list = list(TEMPLATE2VEC.keys())
    return np.array([counter.get(lt, 0) for lt in lt_list], dtype=float)

def extract_temporal(seq):
    if len(seq) < 2:
        return np.array([])
    ts = [ts2sec(str(log["ts"])) for log in seq]
    deltas = [ts[i+1] - ts[i] for i in range(len(ts)-1)]
    inv = 1 / (np.array(deltas) + 1e-3)
    norm = z_score_normalize(inv)
    return norm

def extract_parametric(seq):
    lt2pvs = defaultdict(list)
    for log in seq:
        lt2pvs[log["LT"]].extend(list(log["PV"].values()))
    flat = []
    for lt in TEMPLATE2VEC.keys():
        flat.extend(lt2pvs.get(lt, []))
    def _hash(x):
        return hash(str(x)) % 32
    vec = np.zeros(32)
    for v in flat:
        vec[_hash(v)] += 1
    return vec

def build_synthesized_pattern(seq):
    seq_pat = extract_sequential(seq)
    sem_pat = extract_semantic(seq)
    num_pat = extract_quantitative(seq)
    tim_pat = extract_temporal(seq)
    par_pat = extract_parametric(seq)
    seq_feat = np.array([len(seq_pat), np.mean(seq_pat) if seq_pat else 0])
    if tim_pat.size == 0:
        tim_feat = np.zeros(2)
    else:
        tim_feat = np.array([tim_pat.mean(), tim_pat.std()])
    fused = np.concatenate([seq_feat, sem_pat, num_pat, tim_feat, par_pat])
    return fused

def extract_all(sequences):
    global TEMPLATE2VEC
    templates = extract_all_templates(sequences)
    TEMPLATE2VEC = {tmpl: get_template_embedding(tmpl) for tmpl in templates}
    X = []
    for seq in sequences:
        X.append(build_synthesized_pattern(seq))
    return np.array(X)

if __name__ == "__main__":
    from log_parser import parse_pipeline
    print("Feature extractor ready. Use with real CSV input via parse_pipeline.")