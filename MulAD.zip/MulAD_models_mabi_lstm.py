import torch
import torch.nn as nn

class MABiLSTM(nn.Module):
    def __init__(self, input_dim, hidden_dim=128, num_heads=4, num_layers=2, dropout=0.1):
        super().__init__()
        self.lstm = nn.LSTM(input_dim, hidden_dim, num_layers, 
                            batch_first=True, bidirectional=True, dropout=dropout)
        self.attn = nn.MultiheadAttention(hidden_dim*2, num_heads, batch_first=True)
        self.fc = nn.Sequential(
            nn.Linear(hidden_dim*4, 64),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(64, 2)  
        )
    
    def forward(self, x):
        lstm_out, _ = self.lstm(x)
        attn_out, _ = self.attn(lstm_out, lstm_out, lstm_out)
        fused = torch.cat([lstm_out, attn_out], dim=-1)
        pooled = fused.mean(dim=1)
        logits = self.fc(pooled)
        return logits

def build_mabi_dataset(X_vec, seq_len=10):
    X = []
    for vec in X_vec:
        vec = torch.tensor(vec, dtype=torch.float32)
        if vec.size(0) < seq_len:
            pad = torch.zeros(seq_len - vec.size(0), vec.size(0))
            seq = torch.cat([vec.unsqueeze(0).repeat(vec.size(0), 1), pad], dim=0)[:seq_len]
        else:
            seq = vec[:seq_len].unsqueeze(0)
        X.append(seq)
    return torch.stack(X)

if __name__ == "__main__":
    dummy = torch.randn(8, 10, 64)
    model = MABiLSTM(input_dim=64)
    out = model(dummy)
    print("MABi-LSTM:", out.shape)