import os
import json
import pickle
import numpy as np
import pandas as pd
from datetime import datetime

def ensure_dir(path):
    os.makedirs(path, exist_ok=True)

def save_pkl(obj, path):
    with open(path, 'wb') as f:
        pickle.dump(obj, f)

def load_pkl(path):
    with open(path, 'rb') as f:
        return pickle.load(f)

def ts2sec(ts_str):
    try:
        return datetime.fromisoformat(ts_str).timestamp()
    except:
        return float(ts_str)

def z_score_normalize(arr, eps=1e-8):
    arr = np.array(arr)
    mu, sigma = arr.mean(), arr.std()
    if sigma == 0:
        return np.zeros_like(arr)
    return (arr - mu) / (sigma + eps)