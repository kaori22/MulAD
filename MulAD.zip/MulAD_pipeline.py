import os
import numpy as np
import torch
from sklearn.model_selection import train_test_split
from torch.utils.data import TensorDataset, DataLoader
from torch_geometric.loader import DataLoader as GeoLoader

from log_parser import parse_pipeline
from feature_extractor import extract_all
from models_mabi_lstm import MABiLSTM, build_mabi_dataset
from models_transformer import SimpleTransformer
from models_gnn import SimpleGNN, build_graph_dataset
from models_rf_trainer import train_rf, eval_rf, load_rf
from utils import ensure_dir, save_pkl, load_pkl

SEQ_LEN      = 10
BATCH_SIZE   = 32
EPOCHS       = 5
LR           = 1e-3
HIDDEN_DIM   = 128
DEVICE       = torch.device("cuda" if torch.cuda.is_available() else "cpu")

OUTPUT_DIR   = "output"
os.makedirs(OUTPUT_DIR, exist_ok=True)

def generate_dummy_labels(X):
    lens = [len(x) for x in X]
    y = (np.array(lens) > 15).astype(int)
    return y

def train_torch_model(model, train_loader, val_loader, save_path):
    model.to(DEVICE)
    opt = torch.optim.Adam(model.parameters(), lr=LR)
    criterion = torch.nn.CrossEntropyLoss()
    best = 0
    for epoch in range(EPOCHS):
        model.train()
        for xb, yb in train_loader:
            xb, yb = xb.to(DEVICE), yb.to(DEVICE)
            opt.zero_grad()
            logits = model(xb)
            loss = criterion(logits, yb)
            loss.backward()
            opt.step()
        model.eval()
        correct, total = 0, 0
        with torch.no_grad():
            for xb, yb in val_loader:
                xb, yb = xb.to(DEVICE), yb.to(DEVICE)
                logits = model(xb)
                pred = logits.argmax(1)
                total += yb.size(0)
                correct += (pred == yb).sum().item()
        acc = correct / total
        if acc > best:
            best = acc
            torch.save(model.state_dict(), save_path)
        print(f"Epoch {epoch+1}/{EPOCHS}  acc={acc:.3f}")
    model.load_state_dict(torch.load(save_path))
    return model

def train_gnn_model(model, train_loader, val_loader, save_path):
    model.to(DEVICE)
    opt = torch.optim.Adam(model.parameters(), lr=LR)
    criterion = torch.nn.CrossEntropyLoss()
    best = 0
    for epoch in range(EPOCHS):
        model.train()
        for data in train_loader:
            data = data.to(DEVICE)
            opt.zero_grad()
            logits = model(data)
            loss = criterion(logits, data.y)
            loss.backward()
            opt.step()
        model.eval()
        correct, total = 0, 0
        with torch.no_grad():
            for data in val_loader:
                data = data.to(DEVICE)
                logits = model(data)
                pred = logits.argmax(1)
                total += data.y.size(0)
                correct += (pred == data.y).sum().item()
        acc = correct / total
        if acc > best:
            best = acc
            torch.save(model.state_dict(), save_path)
        print(f"GNN Epoch {epoch+1}/{EPOCHS}  acc={acc:.3f}")
    model.load_state_dict(torch.load(save_path))
    return model

def infer_torch(model, loader):
    model.eval()
    probs = []
    with torch.no_grad():
        for xb, _ in loader:
            xb = xb.to(DEVICE)
            logits = model(xb)
            prob = torch.softmax(logits, dim=1).cpu().numpy()
            probs.append(prob)
    return np.concatenate(probs, axis=0)

def infer_gnn(model, loader):
    model.eval()
    probs = []
    with torch.no_grad():
        for data in loader:
            data = data.to(DEVICE)
            logits = model(data)
            prob = torch.softmax(logits, dim=1).cpu().numpy()
            probs.append(prob)
    return np.concatenate(probs, axis=0)

def main(csv_path):
    print("=== 1. Log Parsing ===")
    sequences = parse_pipeline(csv_path)
    print(f"Number of sequences: {len(sequences)}")
    print("=== 2. Feature Extraction ===")
    X_vec = extract_all(sequences)
    y = generate_dummy_labels(sequences)
    X_train, X_test, y_train, y_test = train_test_split(X_vec, y, test_size=0.2, random_state=42)
    print("=== 3. MABi-LSTM Training ===")
    X_seq = build_mabi_dataset(X_train, seq_len=SEQ_LEN)
    X_seq_test = build_mabi_dataset(X_test, seq_len=SEQ_LEN)
    train_loader = DataLoader(TensorDataset(torch.tensor(X_seq, dtype=torch.float32), torch.tensor(y_train, dtype=torch.long)), batch_size=BATCH_SIZE, shuffle=True)
    val_loader   = DataLoader(TensorDataset(torch.tensor(X_seq_test, dtype=torch.float32), torch.tensor(y_test, dtype=torch.long)), batch_size=BATCH_SIZE)
    mabi_model = MABiLSTM(input_dim=X_vec.shape[1])
    mabi_model = train_torch_model(mabi_model, train_loader, val_loader, 
                                   os.path.join(OUTPUT_DIR, "mabi_lstm.pt"))
    prob_mabi_train = infer_torch(mabi_model, DataLoader(TensorDataset(torch.tensor(X_seq, dtype=torch.float32), torch.tensor(y_train, dtype=torch.long)), batch_size=BATCH_SIZE))
    prob_mabi_test  = infer_torch(mabi_model, DataLoader(TensorDataset(torch.tensor(X_seq_test, dtype=torch.float32), torch.tensor(y_test, dtype=torch.long)), batch_size=BATCH_SIZE))
    print("=== 4. Transformer Training ===")
    trans_model = SimpleTransformer(input_dim=X_vec.shape[1])
    trans_model = train_torch_model(trans_model, train_loader, val_loader, 
                                    os.path.join(OUTPUT_DIR, "transformer.pt"))
    prob_trans_train = infer_torch(trans_model, DataLoader(TensorDataset(torch.tensor(X_seq, dtype=torch.float32), torch.tensor(y_train, dtype=torch.long)), batch_size=BATCH_SIZE))
    prob_trans_test  = infer_torch(trans_model, DataLoader(TensorDataset(torch.tensor(X_seq_test, dtype=torch.float32), torch.tensor(y_test, dtype=torch.long)), batch_size=BATCH_SIZE))
    print("=== 5. GNN Training ===")
    seq_idx_train = [list(range(len(seq))) for seq in sequences[:len(X_train)] if len(seq) >= 3]
    seq_idx_test  = [list(range(len(seq))) for seq in sequences[len(X_train):len(X_train)+len(X_test)] if len(seq) >= 3]
    graph_train = build_graph_dataset(X_train[:len(seq_idx_train)], seq_idx_train)
    graph_test  = build_graph_dataset(X_test[:len(seq_idx_test)], seq_idx_test)
    y_train_gnn = y_train[:len(seq_idx_train)]
    y_test_gnn = y_test[:len(seq_idx_test)]
    for g, label in zip(graph_train, y_train_gnn):
        g.y = torch.tensor([label], dtype=torch.long)
    for g, label in zip(graph_test, y_test_gnn):
        g.y = torch.tensor([label], dtype=torch.long)
    train_loader_gnn = GeoLoader(graph_train, batch_size=BATCH_SIZE, shuffle=True)
    val_loader_gnn   = GeoLoader(graph_test,  batch_size=BATCH_SIZE)
    gnn_model = SimpleGNN(node_dim=X_vec.shape[1])
    gnn_model = train_gnn_model(gnn_model, train_loader_gnn, val_loader_gnn, 
                                os.path.join(OUTPUT_DIR, "gnn.pt"))
    prob_gnn_train = infer_gnn(gnn_model, GeoLoader(graph_train, batch_size=BATCH_SIZE))
    prob_gnn_test  = infer_gnn(gnn_model, GeoLoader(graph_test,  batch_size=BATCH_SIZE))
    print("=== 6. RF Ensemble ===")
    clf = train_rf([prob_mabi_train, prob_trans_train, prob_gnn_train], y_train_gnn,
                   os.path.join(OUTPUT_DIR, "rf.pkl"))
    metrics = eval_rf(clf, [prob_mabi_test, prob_trans_test, prob_gnn_test], y_test_gnn)
    print("Results:", metrics)
    test_probs = np.concatenate([prob_mabi_test, prob_trans_test, prob_gnn_test], axis=1)
    anomaly_scores = clf.predict_proba(test_probs)[:, 1]
    np.savetxt(os.path.join(OUTPUT_DIR, "anomaly_scores.csv"), anomaly_scores)
    with open(os.path.join(OUTPUT_DIR, "metrics.txt"), "w") as f:
        f.write(str(metrics))
    print("=== Output saved to output/ ===")

if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1:
        csv_path = sys.argv[1]
        main(csv_path)
    else:
        print("Usage: python MulAD_pipeline.py <csv_path>")