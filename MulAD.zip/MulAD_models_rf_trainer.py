import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import precision_recall_fscore_support, roc_auc_score
import joblib

def train_rf(X_three, y, save_path):
    X = np.concatenate(X_three, axis=1)
    clf = RandomForestClassifier(n_estimators=300, max_depth=None, random_state=42)
    clf.fit(X, y)
    joblib.dump(clf, save_path)
    return clf

def eval_rf(clf, X_three, y):
    X = np.concatenate(X_three, axis=1)
    pred = clf.predict(X)
    prob = clf.predict_proba(X)[:, 1]
    p, r, f1, _ = precision_recall_fscore_support(y, pred, average='binary')
    auc = roc_auc_score(y, prob)
    return {"precision": p, "recall": r, "f1": f1, "auc": auc}

def load_rf(path):
    return joblib.load(path)