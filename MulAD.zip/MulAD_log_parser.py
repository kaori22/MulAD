import re
import pandas as pd
from collections import defaultdict
from utils import ts2sec
from logparser import Drain

def read_csv_logs(csv_path):
    try:
        df = pd.read_csv(csv_path)
        if 'timestamp' not in df.columns or 'message' not in df.columns:
            raise ValueError("CSV must have 'timestamp' and 'message' columns.")
        logs = [(row['timestamp'], row['message']) for _, row in df.iterrows()]
        return logs
    except Exception as e:
        raise RuntimeError(f"Error reading CSV: {e}")

def simple_parse(logs):
    parser = Drain.LogParser(
        log_format='<Content>',
        outdir='./drain_output/',
        depth=4,
        st=0.5,
        maxChild=100
    )
    log_df = pd.DataFrame(
        [{'LineId': idx+1, 'Content': msg} for idx, (_, msg) in enumerate(logs)],
        columns=['LineId', 'Content']
    )
    parsed_logs = parser.parse_from_df(log_df)
    structured = []
    for idx, (ts, _) in enumerate(logs):
        log_event = parsed_logs[parsed_logs['LineId'] == idx+1].iloc[0]
        template = log_event['EventTemplate']
        params = {f'param_{i}': v for i, v in enumerate(log_event['Parameters'])} if log_event['Parameters'] else {}
        structured.append({
            "ts": ts,
            "LT": template,
            "PV": params
        })
    return structured

def alias_merge(structured, alpha=3, beta=10):
    param_values = defaultdict(set)
    for log in structured:
        for k, v in log["PV"].items():
            param_values[k].add(str(v))
    alias_map = {}
    keys = list(param_values.keys())
    for i in range(len(keys)):
        for j in range(i+1, len(keys)):
            vi, vj = param_values[keys[i]], param_values[keys[j]]
            inter = vi & vj
            if len(inter) >= alpha and min(len(vi), len(vj)) >= beta:
                alias_map[keys[j]] = keys[i]
    for log in structured:
        new_pv = {}
        for k, v in log["PV"].items():
            nk = alias_map.get(k, k)
            new_pv[nk] = v
        log["PV"] = new_pv
    return structured

def serialize(structured):
    groups = defaultdict(list)
    for log in structured:
        if not log["PV"]:
            key = "no_param"
        else:
            key = list(log["PV"].values())[0]
        groups[key].append(log)
    sequences = []
    for k, logs in groups.items():
        seq = sorted(logs, key=lambda x: x["ts"])
        sequences.append(seq)
    return sequences

def parse_pipeline(csv_path):
    raw_logs = read_csv_logs(csv_path)
    structured = simple_parse(raw_logs)
    structured = alias_merge(structured)
    sequences = serialize(structured)
    return sequences

if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1:
        csv_path = sys.argv[1]
        seqs = parse_pipeline(csv_path)
        print(f"{len(seqs)} sequences, such as:")
        for s in seqs[:2]:
            print(s)
    else:
        print("Usage: python MulAD_log_parser.py <csv_path>")